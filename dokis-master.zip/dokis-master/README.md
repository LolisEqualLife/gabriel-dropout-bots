# dokis
This is the repository for the doki bots, where all changes and bugfixes will be staged
DO NOT COPY THESE FILES TO RUN YOUR OWN INSTANCES - THIS IS PROHIBITED


----------------------------------------------------------------------------------------------

The "master" branch is the home of all the doki's, this branch is used for launch purposes and such.

Please do not modify any contents within the "master" branch and instead do so in the "Rewrite-dev" branch, more detail about the "Rewrite-dev" branch is in the "README.md" file within the "Rewrite-dev" branch


If your looking for the legacy doki code, please see
https://github.com/sayori34/legacy-dokis
